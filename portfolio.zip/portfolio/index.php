<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css">
</head>
<body> 
<nav class="navbar">
    <div class="navbar-container">
      <div class="logo">
      <a href="#" class="navbar-logo">Naveen Madiwal</a>
      </div>
      <div class="menus">
      <ul class="navbar-menu">
        <li class="navbar-item"><a href="#home" class="navbar-link">Home</a></li>
        <li class="navbar-item"><a href="#about" class="navbar-link">Skills</a></li>
        <li class="navbar-item"><a href="#services" class="navbar-link">Projects</a></li>
        <li class="navbar-item"><a href="#contact" class="navbar-link">About</a></li>
        <li class="navbar-item"><a href="#contact" class="navbar-link">Contact</a></li>
      </ul>
      </div>
    </div>
  </nav> 
    <video autoplay loop muted playsinline id="background-video">
    <source src="medias/background-video.mp4" type="video/mp4"> 
  </video>


<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"  ></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js"></script>
</body>
</html>